import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhotouploadPage } from './photoupload';

@NgModule({
  declarations: [],
  imports: [],
})
export class PhotouploadPageModule { }
