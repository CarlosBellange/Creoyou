import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CommentPage } from './comment';

@NgModule({
  declarations: [],
  imports: [],
})
export class CommentPageModule { }
