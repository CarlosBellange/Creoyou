import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhotoviewPage } from './photoview';

@NgModule({
  declarations: [],
  imports: [],
})
export class PhotoviewPageModule { }
