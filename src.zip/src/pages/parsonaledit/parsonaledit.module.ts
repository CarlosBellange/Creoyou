import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ParsonaleditPage } from './parsonaledit';

@NgModule({
  declarations: [],
  imports: [],
})
export class ParsonaleditPageModule { }
