import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobapplyPage } from './jobapply';

@NgModule({
  declarations: [],
  imports: [],
})
export class JobapplyPageModule { }
