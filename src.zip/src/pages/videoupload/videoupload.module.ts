import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VideouploadPage } from './videoupload';

@NgModule({
  declarations: [],
  imports: [],
})
export class VideouploadPageModule { }
