import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NotificationsettingsPage } from './notificationsettings';

@NgModule({
  declarations: [],
  imports: [],
})
export class NotificationsettingsPageModule { }
