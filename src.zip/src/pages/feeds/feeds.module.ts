import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FeedsPage } from './feeds';

@NgModule({
  declarations: [],
  imports: [],
})
export class FeedsPageModule { }
