import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AudiosPage } from './audios';

@NgModule({
  declarations: [],
  imports: [],
})
export class AudiosPageModule { }
