import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NewmessagePage } from './newmessage';

@NgModule({
  declarations: [],
  imports: [],
})
export class NewmessagePageModule { }
