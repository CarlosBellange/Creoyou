import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NotificationsdetailsPage } from './notificationsdetails';

@NgModule({
  declarations: [],
  imports: [],
})
export class NotificationsdetailsPageModule { }
