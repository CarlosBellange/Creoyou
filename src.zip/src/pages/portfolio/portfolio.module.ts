import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PortfolioPage } from './portfolio';

@NgModule({
  declarations: [],
  imports: [],
})
export class PortfolioPageModule { }
