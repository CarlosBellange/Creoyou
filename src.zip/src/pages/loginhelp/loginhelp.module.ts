import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoginhelpPage } from './loginhelp';

@NgModule({
  declarations: [],
  imports: [],
})
export class LoginhelpPageModule { }
