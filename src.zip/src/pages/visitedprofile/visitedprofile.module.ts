import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VisitedprofilePage } from './visitedprofile';

@NgModule({
  declarations: [],
  imports: [],
})
export class VisitedprofilePageModule { }
