import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AboutmePage } from './aboutme';

@NgModule({
  declarations: [],
  imports: [],
})
export class AboutmePageModule { }
