import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdvertisementdetailsPage } from './advertisementdetails';

@NgModule({
  declarations: [],
  imports: [],
})
export class AdvertisementdetailsPageModule { }
