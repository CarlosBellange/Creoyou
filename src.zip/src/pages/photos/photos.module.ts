import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhotosPage } from './photos';

@NgModule({
  declarations: [],
  imports: [],
})
export class PhotosPageModule { }
