import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EventcreatePage } from './eventcreate';

@NgModule({
  declarations: [],
  imports: [],
})
export class EventcreatePageModule { }
