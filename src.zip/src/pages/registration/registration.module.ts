import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistrationPage } from './registration';

@NgModule({
  declarations: [],
  imports: [],
})
export class RegistrationPageModule { }
