import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SocialregPage } from './socialreg';

@NgModule({
  declarations: [],
  imports: [],
})
export class SocialregPageModule { }
