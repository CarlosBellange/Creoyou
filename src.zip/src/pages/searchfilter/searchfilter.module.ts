import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SearchfilterPage } from './searchfilter';

@NgModule({
  declarations: [],
  imports: [],
})
export class SearchfilterPageModule { }
