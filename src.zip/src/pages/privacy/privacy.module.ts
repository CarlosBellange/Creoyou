import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PrivacyPage } from './privacy';

@NgModule({
  declarations: [],
  imports: [],
})
export class PrivacyPageModule { }
