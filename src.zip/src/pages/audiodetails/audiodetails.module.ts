import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AudiodetailsPage } from './audiodetails';

@NgModule({
  declarations: [],
  imports: [],
})
export class AudiodetailsPageModule { }
