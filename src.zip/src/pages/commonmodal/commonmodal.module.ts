import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CommonmodalPage } from './commonmodal';

@NgModule({
  declarations: [],
  imports: [],
})
export class CommonmodalPageModule { }
