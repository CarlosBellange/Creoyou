import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AudiocommentPage } from './audiocomment';

@NgModule({
  declarations: [],
  imports: [],
})
export class AudiocommentPageModule { }
