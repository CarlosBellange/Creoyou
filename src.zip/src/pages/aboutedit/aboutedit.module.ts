import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AbouteditPage } from './aboutedit';

@NgModule({
  declarations: [],
  imports: [],
})
export class AbouteditPageModule { }
