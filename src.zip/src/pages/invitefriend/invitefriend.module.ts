import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { InvitefriendPage } from './invitefriend';

@NgModule({
  declarations: [],
  imports: [],
})
export class InvitefriendPageModule { }
