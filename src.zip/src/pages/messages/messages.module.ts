import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MessagesPage } from './messages';

@NgModule({
  declarations: [],
  imports: [],
})
export class MessagesPageModule { }
