import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProfilecompletePage } from './profilecomplete';

@NgModule({
  declarations: [],
  imports: [],
})
export class ProfilecompletePageModule { }
