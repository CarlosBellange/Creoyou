import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PremiumuserPage } from './premiumuser';

@NgModule({
  declarations: [],
  imports: [],
})
export class PremiumuserPageModule { }
