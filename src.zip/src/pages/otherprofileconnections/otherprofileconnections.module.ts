import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OtherprofileconnectionsPage } from './otherprofileconnections';

@NgModule({
  declarations: [],
  imports: [],
})
export class OtherprofileconnectionsPageModule { }
