import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VideocommentPage } from './videocomment';

@NgModule({
  declarations: [],
  imports: [],
})
export class VideocommentPageModule { }
