import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhotodetailsPage } from './photodetails';

@NgModule({
  declarations: [],
  imports: [],
})
export class PhotodetailsPageModule { }
