import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JobdetailsPage } from './jobdetails';

@NgModule({
  declarations: [],
  imports: [],
})
export class JobdetailsPageModule { }
