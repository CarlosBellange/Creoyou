import { NgModule } from '@angular/core';
import { TextgrowDirective } from './textgrow/textgrow';
import { ImgPreloadDirective } from './img-preload/img-preload';
@NgModule({
	declarations: [],
	imports: [],
	exports: []
})
export class DirectivesModule { }
